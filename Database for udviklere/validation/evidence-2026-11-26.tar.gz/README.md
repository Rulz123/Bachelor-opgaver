# Actual local validation: 26 November 2026

## Latest: snapshot correction after Nichlas pull

The work branch was subsequently fast-forwarded to `d743bb3` from `origin/Nichlas`.
With the incoming snapshot methods, the live suite passed 9 tests and failed 42:
EF could not bind the `PublishedSnapshot` DTO constructor's Window/Routes parameters.
The local correction removes that DTO from the EF model and uses the existing
SnapshotDocument JSONB mapping instead. Publication now uses the shared transaction
and per-ID advisory lock, detects retries/window conflicts, preserves the original
timestamp and invokes the failure hook before commit. Reads deserialize stored data.

The rebuilt Docker image passed all 10 SnapshotTests, then all 51 tests (0 failed/skipped)
against the isolated `mobility_l07_test` database. No tests were changed for this fix.
Current evidence: `dbd-l07-snapshot-fix-focused.log`, `dbd-l07-snapshot-fix-full.log`
and `lecture07-snapshot-fix-full.trx`. Earlier failing evidence is retained.
The sections below record the original validation run and its commands/measurements.

Base: `origin/Nichlas`, `04468300be8861410d7f93905e52afd7fccd90e3`.
Branch: `work/josephine-dbd-complete`. The initial worktree was clean.
No applicable AGENTS.md was found. Read the package at
`/home/josephine/Downloads/DBD-rettelser/START-HER.txt`, then ran
`git apply --check /home/josephine/Downloads/DBD-rettelser/DBD-rettelser.patch`
and `git apply` on that file. No commit, push, merge, reset or Moodle submission.

## Isolation

All services belong to new `dbdverify-lNN-20261126` Compose projects. Existing
unrelated containers/data/volumes were left alone; no volumes were deleted.
Every fixture reset ran in these isolated lab services, never an existing user database.
Lecture 7 uses `mobility_l07_test` for tests and its isolated `mobility_l07` for CLI runs.
Lecture 4's runner creates and retains an additional `dbdverify_l04_*` database per run.
Lecture 11 uses unique report IDs and retains receipts in a printed
`/tmp/dbd-l11-receipts-*` directory.

Docker Engine 29.8.1; Compose v5.5.1; host SDKs 8.0.131 and 10.0.112.
Lecture 7 built with its pinned Docker SDK 8.0.426 and VSTest/xUnit configuration.
Its database reported PostgreSQL 17.11. MongoDB/Redis/S3 use project images.
All .NET projects under this course were built: CacheLab, lecture 7 app/tests,
reports Application/Infrastructure/CLI, and WorkflowChecks.

Final service state: isolated lesson 6 MongoDB/Redis, lesson 7/8/9 PostgreSQL,
lesson 10 replica set/client and lesson 11 PostgreSQL/object storage remain running.
Lesson 1-5 services are stopped, not deleted. Lesson 7 currently owns host port 5432;
lesson 6 owns 27017/6379. Stop those isolated services before starting an earlier lesson
that needs the same port. Lesson 11 uses 127.0.0.1:25411/19011.

## Results

Counts are distinct checks, not repeated executions. Expected rejected writes and
outages are successful negative checks, not successful business operations.

| Lesson | Changes | Automated checks | Final status | Actual execution | Remaining scope |
|---|---|---:|---|---|---|
| 1 | Fix seed column/IDs/order and 3 parameterized queries | 0 | Smoke passed | Fresh init; repeat seed added 0; 24 trips, 12 stops; 3 queries ran | No assertion suite; wider ER/access-map/dossier deliverables not verified |
| 2 | Select original init DDL; integrity migration and SQLSTATE tests | 12 | 12 passed | Invalid writes rejected; valid payment accepted; tests roll back | Cross-row capacity, external payment, retention are workflow policies |
| 3 | Restore insert-only trigger; repeatable reporting checks | 8 | 8 passed | All 4 reporting methods compared after 6 mutations and refresh | Summary deliberately stale after corrections; not a production solution |
| 4 | Repair migrations, readers/writers and pair FK; add tests | 13 | 13 passed | Expansion, backfill, conflicts, historical prices, ID-only access | Actual retirement of old application versions and ID permissions are operational |
| 5 | No code changes | 10 | 10 passed | Search, A/B/C updates, alternative model, BSON growth, invalid-document rejection | Demonstrations are not an atomic cross-document update workflow |
| 6 | Embedded cancellation fix; live runner | 14 | 14 passed | Cache hits/expiry/corruption/cancellation, real outages/recovery, concurrency and Lua | Cold batch made 10 Mongo reads; no request coalescing; cache is not booking authority |
| 7 | Booking/snapshot patch; unseal snapshot entity for EF baseline | 51 | 51 passed, 0 failed/skipped | Whole suite on PostgreSQL; separate CLI processes; small/100k-trip measurements | No remaining suite failure; not production load certification |
| 8 | UTC query correction | 4 | 4 passed before/after index | 40 measured EXPLAIN ANALYZE plans, index inventory, partition comparison | Local sequential timings, not controlled production benchmarks |
| 9 | Parallel-session checks | 13 SQL assertions + 6 concurrent | All passed | Idempotency, last seats, conflicts, rollback, cancellation | Deterministic deadlock, explicit lock variants and stronger-isolation retries not rerun |
| 10 | Verifier patch; replica integration checks | 7 supplied + 12 package + 13 live | 32 passed | Reads, failover, w=3 timeout, no primary, recovery | All members share one host; no host-failure claim |
| 11 | Workflow/Infrastructure patch; live checks | 14 workflow + 14 live | 28 passed | Exact versions, corrupt receipt, predecessor rollback, retries, both outages | Upload/receipt crash gap and retention need operational policy |

### Failures observed

- First lecture 7 run: 48 passed, 3 failed. The new sealed SnapshotDocument blocked EF
  proxy model creation during baseline measurements. Removing `sealed` fixed all three;
  the complete rerun passed 51/51.
- First new cache-runner attempt expected one changed document; the fixture has two
  copies of the trip. Correcting the expectation produced 14/14.
- Inspection found lecture 1's nonexistent `route_stops.name`, lecture 2's duplicate/broken
  init scripts, lecture 3's `after deletes`, and lecture 4's invalid
  `DROP CONSTRAINT function()` and duplicate writer. Corrected before successful live runs.
- Lecture 5 `validation.js` exited 1 with `MongoServerError: Document failed validation`.
  This is the intended negative experiment.
- `git diff --check` initially found a blank EOF line; it was fixed and the check passed.
  Editor diagnostics found no errors in the checked new runner/snapshot files.

## Measurements

### Lecture 7

| Fixture/read | Executed reads | Route entities | Trip entities |
|---|---:|---:|---:|
| 4 routes / 9 trips, lazy baseline | 5 | 4 | 9 |
| 4 routes / 9 trips, live projection | 1 | 0 | 0 |
| Published snapshot read | 1 | 0 | 0 |
| 200 routes / 100,000 trips, lazy baseline | 201 | 200 | 100000 |
| 200 routes / 100,000 trips, live projection | 1 | 0 | 0 |

T201 returned Booked then AlreadyBooked, both with receipt timestamp
`2026-11-26T10:55:09.108615Z`. Cancelled T102 returned Cancelled, exit 2.
R1 rename/T102 cancellation changed the live board but not the original snapshot.
The full suite covers new contexts/apps, request conflicts, booking/cancellation races,
immutable snapshots, publication conflicts, time precision and rollback.

### Lecture 8

Five measured plans per row after an unrecorded warm-up. Times are PostgreSQL
Execution Time in milliseconds, not Docker wall time. Other work ran on this laptop.

| Route | Query/index | Median | Min-max |
|---|---|---:|---|
| R-7 | Baseline / PK | 38.878 | 30.922-43.113 |
| R-0 | Baseline / PK | 56.874 | 49.004-110.076 |
| R-7 | Rewrite / PK | 24.482 | 21.973-32.454 |
| R-0 | Rewrite / PK | 31.917 | 20.450-39.530 |
| R-7 | Rewrite / route-only | 4.824 | 3.471-5.907 |
| R-0 | Rewrite / route-only | 30.610 | 22.761-33.109 |
| R-7 | Rewrite / partial composite | 0.241 | 0.228-0.348 |
| R-0 | Rewrite / partial composite | 0.344 | 0.227-0.377 |

Composite definition: `(route_id, scheduled_departure_utc, id) WHERE status='Scheduled'`;
size 4408 kB, PK 2640 kB. Both final plans actually used
`index_trips_route_departure_status`. Keep this candidate for this workload, allowing for
insert/reschedule/cancel maintenance costs. Checks returned identical ordered 20-row pages
and 38/991-row days. Raw plans retain top-node buffers and partition observations.

### Other observations

- Lecture 3 Failed-to-Captured correction: direct/function 122, insert summary 36, MV 36.
- Lecture 4 retained TICKET-3's 65.00 DKK while the current product price was 80 DKK.
- Lecture 5: 100 departures = 12,307 BSON bytes; 1000 = 123,007. Alternative: 6 -> 10 documents.
- Lecture 9: ten identical requests returned one ID; twenty distinct requests for two seats
  gave two successes/eighteen full-trip rejections. All counters matched booking rows.
- Lecture 10: w=3 with two members gave UnknownWriteOutcome, yet the same operation was
  Present/PresentMatches. Without primary, UnknownReadFailure; after recovery, PresentMatches.
- Lecture 11 original version `2c51cb34-dbed-40b4-9932-e0a8f3fa8070`: 3 rows;
  correction `79c94658-c40d-426d-be64-c9cf3bdc6985`: 4 rows. Both verified after recovery.

## Exact commands

Define this Bash helper once. It only selects a directory and our isolated project:

```bash
DBD_ROOT='/home/josephine/Bachelor-opgaver/Database for udviklere'
dbd() {
    local number="$1"
    local folder="$DBD_ROOT/Lektion $number/mobilityticketing-lecture-$number-starter-main"
    if [[ "$number" != 7 && "$number" != 8 ]]; then
        folder="$folder/mobilityticketing-lecture-$number-starter-main"
    fi
    cd "$folder" || return
    printf -v COMPOSE_PROJECT_NAME 'dbdverify-l%02d-20261126' "$number"
    export COMPOSE_PROJECT_NAME
}
```

Lessons 1-5/7 compete for host port 5432. Before switching between them, run
`docker compose stop postgres` in the preceding **dbdverify** project. Before switching
5/6, stop its `mongo` similarly. Never stop unrelated services. Use `stop`, not `down -v`.
These commands resume retained test environments; fresh environments need the one-time
migrations indicated below. Fresh project suffixes give separate volumes/containers.

### Lecture 1

```bash
dbd 1
docker compose up -d postgres
docker compose exec -T postgres pg_isready -U mobility -d mobility
docker compose exec -T postgres psql -X -U mobility -d mobility -v ON_ERROR_STOP=1 -f /docker-entrypoint-initdb.d/002_seed.sql
docker compose exec -T postgres psql -X -U mobility -d mobility -v ON_ERROR_STOP=1 -v route_id=LINE-M2 -v after_utc=2000-01-01T00:00:00Z -v service_date=2026-11-26 -f /docker-entrypoint-initdb.d/003_queries.sql.example
```

Local status: `'1'` scheduled, `'0'` cancelled. Repeated stops are allowed, seed IDs
distinguish visits. Queries use actual routes, including zero-count routes for an empty date.

### Lecture 2

```bash
dbd 2
docker compose up -d --wait postgres
# Fresh environment only; already installed in the retained project:
# docker compose exec -T postgres psql -X -U mobility -d mobility -v ON_ERROR_STOP=1 < database/postgres/migrations/011_ticketing_integrity.sql
docker compose exec -T postgres psql -X -U mobility -d mobility -v ON_ERROR_STOP=1 < database/postgres/experiments/verify.sql
```

Compose loads the saved original DDL, not both competing drafts. The old
`constraints_should_fail.sql` contains pasted output, including a misleading duplicate-ID
error for mismatched ticket identity. Treat it as historical notes, not executable tests;
`verify.sql` now asserts the correct SQLSTATE on uncontaminated test rows.

### Lecture 3

```bash
dbd 3
docker compose up -d --wait postgres
# Fresh environment only, once and in order:
# for file in database/postgres/migrations/*.example; do
#   docker compose exec -T postgres psql -X -U mobility -d mobility -v ON_ERROR_STOP=1 < "$file" || break
# done
docker compose exec -T postgres psql -X -U mobility -d mobility -v ON_ERROR_STOP=1 < database/postgres/experiments/reporting_cases.sql
```

The eight checks assert observed differences, not equality of all copies. Payments are
authoritative; query/function are current at read time, MV at explicit refresh, insert
summary only for inserts. The checks roll back experiment writes.

### Lecture 4

```bash
dbd 4
node database/postgres/experiments/lecture04/verify.cjs
```

Starts Compose, creates a new test database, loads init files and tests all phases.
The new writer takes `ticket_id`, `ticket_code`, `product_id`, `purchase_price`,
`purchase_currency`; it looks up the code from the ID. Direct mismatched SQL fails its FK.

### Lecture 5

```bash
dbd 5
docker compose up -d --wait postgres mongo
docker compose exec -T mongo mongosh --quiet --file /scripts/lecture05/reset.js
docker compose exec -T mongo mongosh --quiet --file /scripts/lecture05/search.test.js
for scenario in A B C; do
    docker compose exec -T mongo mongosh --quiet --file /scripts/lecture05/reset.js
    docker compose exec -T mongo mongosh --quiet --eval "load('/scripts/lecture05/search.js'); load('/scripts/lecture05/updates_test${scenario}.js');"
done
docker compose exec -T mongo mongosh --quiet --file /scripts/lecture05/reset.js
docker compose exec -T mongo mongosh --quiet --file /scripts/lecture05/alternative.js
docker compose exec -T mongo mongosh --quiet --file /scripts/lecture05/alternative_search.js
docker compose exec -T mongo mongosh --quiet --file /scripts/lecture05/growth.js
docker compose exec -T mongo mongosh --quiet --file /scripts/lecture05/reset.js
docker compose exec -T mongo mongosh --quiet --file /scripts/lecture05/validation.js
# Last command deliberately exits 1: Document failed validation.
```

### Lecture 6

```bash
dbd 6
node database/redis/lecture06/verify.cjs
```

Starts services, resets this fixture, builds CacheLab and drives its existing interactive
scenarios. Stops/restores services during outage checks. Manual app:
`dotnet run --project database/redis/lecture06/CacheLab`.

### Lecture 7

```bash
dbd 7
docker compose up -d --wait postgres
docker compose build app tests
docker compose run --rm tests
docker compose run --rm app reset
docker compose run --rm app baseline
docker compose run --rm app overview
docker compose run --rm app publish morning
docker compose run --rm app book T201 campus-1
docker compose run --rm app book T201 campus-1
docker compose run --rm app cancel T102
docker compose run --rm app rename R1 'City Ring'
docker compose run --rm app book T102 cancelled-1
# Expected exit 2 above; continue:
docker compose run --rm app overview
docker compose run --rm app snapshot morning
docker compose run --rm app publish revised
docker compose run --rm app snapshot revised
docker compose run --rm app reset
docker compose run --rm app scale
docker compose run --rm app baseline
docker compose run --rm app overview
```

TRX is written under `docs/evidence/lecture07/tests`; generated evidence directories
are ignored by Git, so this run's logs/TRX are also copied alongside this report.

### Lecture 8

```bash
dbd 8
docker compose up -d --wait postgres
docker compose exec -T postgres bash /lab/run.sh reset
docker compose exec -T postgres bash /lab/run.sh check
for route in R-7 R-0; do
    for query in baseline candidate; do
        docker compose exec -T postgres bash /lab/run.sh measure "$query" "$route"
    done
done
docker compose exec -T postgres psql -U mobility -d mobility_l08 -v ON_ERROR_STOP=1 -c 'CREATE INDEX index_trips_route ON lab08.trips(route_id);'
for route in R-7 R-0; do docker compose exec -T postgres bash /lab/run.sh measure candidate "$route"; done
docker compose exec -T postgres bash /lab/run.sh indexes
docker compose exec -T postgres bash /lab/run.sh check
for route in R-7 R-0; do docker compose exec -T postgres bash /lab/run.sh measure candidate "$route"; done
docker compose exec -T postgres bash /lab/run.sh partitions
```

Measured stdout was redirected to `dbd-l08-{baseline,candidate,routeonly,composite}-R-{0,7}.log`.
Reset/check/inventory/partitions have separately named raw files.

### Lecture 9

```bash
dbd 9
docker compose up -d --wait postgres
# Fresh isolated fixture only: docker compose exec -T postgres bash /lab/run.sh reset
docker compose exec -T postgres bash /lab/run.sh load
docker compose exec -T postgres bash /lab/run.sh check
node sql/concurrency.test.cjs
docker compose exec -T postgres bash /lab/run.sh inspect
```

### Lecture 10

```bash
dbd 10
bash run.sh up
bash run.sh check
node scripts/verify.test.cjs
node scripts/live.test.cjs
bash run.sh status
```

Live tests discover the actual primary, use fresh IDs, and restore members in finally.
No forced replica reconfiguration is performed.

### Lecture 11

```bash
dbd 11
node tests/live.test.cjs
```

Starts services, checks readiness/versioning, builds CLI, runs pure/live checks,
and restores services. Keep printed receipt directories for recovery. Manual commands:

```bash
source ./lab.sh
lab_compose up -d --wait postgres object-store
s3 s3api list-buckets
dotnet run --project tests/WorkflowChecks
dotnet run --project src/MobilityTicketing.Reports -- --help
```

## Evidence and unverified scope

Adjacent `dbd-l*.log`/`.json` files contain actual output; `lecture07-*.trx` contains
the failing/passing tests. `lecture07-logs/` retains generated SQL/measurement files.
Live runners print actions; other exact sequences are above.
Historical package claims and committed timing logs are not new observations. This
report supersedes their earlier "Docker unavailable" status.
No deterministic deadlock/stronger-isolation experiment, external diagram/Notion/Moodle
review or production reliability claim is implied by these passes. No delivery was made.